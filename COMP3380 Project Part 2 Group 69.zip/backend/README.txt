COMP3380 Database Project Part 2
GROUP 69
Millan David
Paul Gameiro

Pokemon Gen 4 Database from Diamond, Pearl, Platinum

Instructions to run our project:

Please upload the files to an AVIARY machine.

There should be:
  auth.cfg
  makefile
  mssql-jdbc-11.2.0.jre11.jar
  pokemon_sql_server.java
  pokemon_sql_server.sql
  README.txt
image.png
You then type:
  make run

Then the program will run and you will be greeted with a command-line interface similar to the one
from assignment 2 question 5. Please ensure that your terminal is big, there is a nice ASCII art we
included and it will make the menu page easier to read. 

The server connects to our Microsoft SQL Server. Feel free to run the SQL file as it will drop all 
the tables and redo the inserts. It should not take THAT long even though it is at least 10 000 lines
of code.


